#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# all indexs starts with 1

###############################
## OPTIMIZATION MODEL

# DEMAND:
Q = read_table(str(data_path+"//Demand//1administrationMatrix.txt"), sep='\t', header=None)
Demand = convert_matrix_format(Q)

OrderEventWeight = 50

B = 3000 #Budget
BudgetPenalty = 1000
EmergencyOrderPenalty = 300

n_days = Q.shape[1]#30

ordinaryDT = 1

FirstWeekDay = 1

n_drugs = Q.shape[0]#18


capacity=read_table(str(data_path+"/Capacity18drugs.txt"), sep='\t')

SharedSpacesSets = tuple(capacity.FlagFrigo) # 1 se frigorifero, 0 se armadietto
Drugs_in_groups=convert_tuple_format(SharedSpacesSets)

n_SharedSpaces = len(np.unique(SharedSpacesSets))#2

Vol = tuple(np.unique(capacity.Vsegnato))
Vg=convert_tuple_format(Vol)

DrugBoxVol = tuple(capacity.Vf)
V=convert_tuple_format(DrugBoxVol)

DrugResCap = tuple(capacity.Cf)
Cf=convert_tuple_format(DrugResCap)

DrugSharedCap = tuple(capacity.Csegnato)
Cf_=convert_tuple_format(DrugSharedCap)

UnitsInBox = tuple(capacity.Dosi_confezione)
U=convert_tuple_format(UnitsInBox)

cost = tuple(capacity.Costo)
c=convert_tuple_format(cost)

PosologGiorn1pz = tuple(capacity.dosi1posologia)
posologGiorn1pz=convert_tuple_format(PosologGiorn1pz)


InitStock = convert_tuple_format(read_table(str(data_path+"/InitStock.txt"), sep='\t').Doses) #posologGiorn1pz.copy()
#newInitStock = {}
curDir=os.path.abspath(os.path.join(data_path, os.pardir))
for i in range(2):
    curDir = os.path.abspath(os.path.join(curDir, os.pardir))

initStock0Path=curDir+"//inputFiles//InitStock_0.txt"
SafeStock = convert_tuple_format(read_table(initStock0Path, sep='\t').Doses)


## STAKEHOLDERS PERSPECTIVES ##
# nurses
Target_Score_Nurses = 3 #{3,5,7} range number of different drugs in ordered
# general direction
Target_Score_GeneralDirection = 285 #{34, 285, 622} drugs exceeding demand
boxesCost = compute_boxesCost()
#clinicians
Target_Score_Clinicians = 24 #{20, 24, 28} numero di gg desiderato di disponibilità di TE > soglia
thresholdScore_Clinicians = 3 # K: daily desiderate variety of therapies
TEdrugs = {1: [14, 15], # in OR
           2: 4,
           3: 5,
           4: [11, 12] # in AND
           }




###############################
## GENERATOR
seeded = None # 1 if there is a seed to use
seed = []

n_beds = 8 # tot number of beds
results_DT = 3 # lab results delay time
treatment_length = 5 #days
planning_horizon = 30 + 7 #n_days + 7 #7= shift di una settimana
#drugsMatrix = {(i,j):0 for i in range(1, n_drugs+1) for j in range(1, planning_horizon+1)}
indexR = 0 # lab issues counter
indexPz = 0 # patient type index
pzCount = 0
indexD = 1 # planning horizon 1st day (day counter)

# daily doses to administrate for each drug
drugDoses = read_table(str(data_path+"/Dosi1posologia.txt"), sep='\t') #capacity.dosi1posologia





