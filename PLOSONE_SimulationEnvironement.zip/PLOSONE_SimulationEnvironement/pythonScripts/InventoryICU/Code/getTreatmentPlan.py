#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#############
import numpy as np
from pandas import *
import pickle
import itertools
import math
import datetime
#from datetime import datetime, timedelta
import time
import sys
import os
from ast import literal_eval
from itertools import groupby


p_classes = 3

# parametri di ingresso
indexPz=int(sys.argv[1])
secondArg=str(sys.argv[2]) # serve a Filippo per l'identificativo del paziente


this_path=str(os.path.dirname(os.path.realpath("__file__" )))
data_path=str(os.path.dirname(os.path.realpath("__file__" + "/../"))+"/Data/")

exec(compile(open(str(this_path + '/functions.py'), 'rb').read(), str(this_path + '/functions.py'), 'exec'))
exec(compile(open(str(this_path + '/distribData.py'), 'rb').read(), str(this_path + '/distribData.py'), 'exec'))

# daily doses to administrate for each drug
capacity = read_table(str(data_path+"Capacity18drugs.txt"), sep='\t')
drugDoses = read_table(str(data_path+"Dosi1posologia.txt"), sep='\t')

# paths
paths = read_table(str(data_path+'Distrib/'+str(p_classes)+'pTypes_TchangesPaths.txt'), sep='\t')
paths.daysDrugs = paths.daysDrugs.apply(literal_eval)


n_beds = 8 # tot number of beds
results_DT = 3 # lab results delay time
treatment_length = 5 #days
n_drugs = 18


pathChoice = -1
TreatmentPlan={(i,j):0 for i in range(1, n_drugs+1) for j in range(1, 82+1)} # inizializzo a 0 la matrice 18 farmaci x max los=82


# 2 alternative:
# - scelta tra tutti i paths possibili
# - scelta prima della nuvoletta e poi di un cammino al suo interno
def getPathIndex(df): # restituisce l'indice del cammino, date le prob dei cammini
    choice = np.random.choice(np.append([i for i in df.index], 'False'), 1, p=np.append([i for i in df.probPath], (1 - sum(i for i in df.probPath))))
    while choice == 'False':
        choice = np.random.choice(np.append([i for i in df.index], 'False'), 1, p=np.append([i for i in df.probPath], (1-sum(i for i in df.probPath))))
    return choice[0]
def pathsGroupChoice(df):
    choice = np.random.choice(np.append([i for i in df.group.unique()], 'False'), 1, p=np.append([i for i in df.groupProb.unique()], (1 - sum(i for i in df.groupProb.unique()))))
    while choice == 'False':
        choice = np.random.choice(np.append([i for i in df.group.unique()], 'False'), 1, p=np.append([i for i in df.groupProb.unique()], (1 - sum(i for i in df.groupProb.unique()))))
    return choice[0]


# il paziente può avere o meno il sospetto di infezione
def labIssueEvent(iPz):  # is there lab issue? (iRic = 0 = current issue occurrences)
    p0 = float(p_req[p_req.TipologiaPaziente == iPz].ProbRichiestaSI)
    dice = int(np.random.choice([0, 1], 1, p=[(1 - p0), (p0)]))
    return dice
# degenza per paziente senza sospetto di infezione
def is_outlier(): #(=5%prob) indipendente dalla tipologia del paziente
    return int(np.random.choice([0, 1], 1, p=[0.95, 0.05]))
def get_noOutlierLOS(iPz):
    # to fix round-off errors:
    dice=(np.random.choice(np.append([i for i in p_LoS_noreq.columns[1:]], 'False'), 1, p=np.append([j for j in p_LoS_noreq[p_LoS_noreq.TipologiaPaziente == iPz].iloc[0][1:].values], (1-sum(j for j in p_LoS_noreq[p_LoS_noreq.TipologiaPaziente == iPz].iloc[0][1:].values)))))[0]
    while dice == 'False':
        dice = (np.random.choice(np.append([i for i in p_LoS_noreq.columns[1:]], 'False'), 1, p=np.append( [j for j in p_LoS_noreq[p_LoS_noreq.TipologiaPaziente == iPz].iloc[0][1:].values], (1 - sum(j for j in p_LoS_noreq[p_LoS_noreq.TipologiaPaziente == iPz].iloc[0][1:].values)))))[0]
    return int(dice)

def getDmatrix(dict_data, x_max, y_max):
    converted = DataFrame()
    for j in range(1, y_max + 1):
        converted[(j)] = [dict_data[i, j] for i in range(1, x_max + 1)]
    return DataFrame(converted)




flag = labIssueEvent(indexPz)
# paziente senza sospetto di infezione
if flag==0:
    outlier = is_outlier()
    if outlier == 1:
        min = int(p_LoS_outlier_noreq[p_LoS_outlier_noreq.TipologiaPaziente == indexPz].Min)
        max = int(p_LoS_outlier_noreq[p_LoS_outlier_noreq.TipologiaPaziente == indexPz].Max)
        los = int(np.random.uniform(min, max))
    else:
        los = get_noOutlierLOS(indexPz)

# paziente con sospetto di infezione
if flag==1:
    pathsPz=paths[paths.p_type==indexPz]

    # metodo1
    #scelta tra tutti i paths possibili
    #pathChoice = getPathIndex(pathsPz)
    # metodo2
    # scelta prima della nuvoletta e poi di un cammino al suo interno:
    idG = int(pathsGroupChoice(pathsPz))
    pathChoice = int(getPathIndex(pathsPz[pathsPz.group==idG]))

    #pathsPz.loc[pathChoice].daysDrugs = farmaci corrispondenti al cammino scelto --> la lunghezza di questo vettore mi dà anche la LOS
    los = len(pathsPz.loc[pathChoice].daysDrugs)+1

    # salvo il piano terapeutico
    for currentDay in range(1,los):
        drug = pathsPz.loc[pathChoice].daysDrugs[currentDay-1]
        if drug!=0:
            if np.isscalar(drug):  # every drug is an int but 4th empirical treatment, which is is a vector of 2 drugs
                TreatmentPlan[drug, currentDay] += int(capacity[capacity.Farmaco == drug].dosi1posologia)
            else:
                TreatmentPlan[drug[0], currentDay] += int(capacity[capacity.Farmaco == drug[0]].dosi1posologia)
                TreatmentPlan[drug[1], currentDay] += int(capacity[capacity.Farmaco == drug[1]].dosi1posologia)
        drug = None
    los-=1


if pathChoice==-1:
    plan=0
else:
    plan=1

# stampo durata degenza+1, id cammino (pathChoice) e piano terapeutico
# stampa di durata della degenza e del piano terapeutico
#fout = open(str(data_path+'/TreatmentPlans/'+str(secondArg)+".txt"), 'w')
fout = open(str(data_path+str(secondArg)+".txt"), 'w')
fout.write(str(str(los)+'\t'+str(plan)+'\t'+str(pathChoice))) #stampa durata degenza per paziente con sospetto infezione
fout.write('\n')
getDmatrix(TreatmentPlan,n_drugs,82).to_csv(fout, sep='\t', index=False, header=False)

fout.write('\n')
fout.close()














# indexPz = patientType()
#
# flag = labIssueEvent(indexPz)
# # paziente senza sospetto di infezione
# if flag==0:
#     outlier = is_outlier()
#     if outlier == 1:
#         min = int(p_LoS_outlier_noreq[p_LoS_outlier_noreq.TipologiaPaziente == indexPz].Min)
#         max = int(p_LoS_outlier_noreq[p_LoS_outlier_noreq.TipologiaPaziente == indexPz].Max)
#         los = int(np.random.uniform(min, max))
#     else:
#         los = get_noOutlierLOS(indexPz)
#
# # paziente con sospetto di infezione
# if flag==1:
#     pathsPz=paths[paths.p_type==indexPz]
#
#     # metodo1
#     #scelta tra tutti i paths possibili
#     #pathChoice = getPathIndex(pathsPz)
#     # metodo2
#     # scelta prima della nuvoletta e poi di un cammino al suo interno:
#     idG = pathsGroupChoice(pathsPz)
#     pathChoice = getPathIndex(pathsPz[pathsPz.group==idG])
#
#     #pathsPz.loc[pathChoice].daysDrugs = farmaci corrispondenti al cammino scelto --> la lunghezza di questo vettore mi dà anche la LOS
#     los = len(pathsPz.loc[pathChoice].daysDrugs)+1
#
# print(indexPz)
# print(los)
# print(pathChoice)
# pathChoice=None
#
