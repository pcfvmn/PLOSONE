#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# format conversions
def dict_to_df(dict_data):
    x_max = max(dict_data.keys())[0]
    y_max = max(dict_data.keys())[1]
    converted = DataFrame()
    for j in range(1, y_max+1):
        converted[(j)] = [dict_data[i,j] for i in range(1, x_max+1)]
    converted = DataFrame(converted)
    return converted

def convert_matrix_format(matrix_data): #matrix_to_pyomo_data_format
    converted={}
    for i in range(matrix_data.shape[0]):
        for j in range(matrix_data.shape[1]):
            converted[(i+1,j+1)]=matrix_data.iloc[i,j]
    return converted
def convert_tuple_format(vector): #vector_to_pyomo_data_format
    converted = {}
    for i in range(len(vector)):
        converted[i+1]=vector[i]
    return converted


# Optimization model
def weekDay(d):
	return int((d+FirstWeekDay-1) % 7) # %=mod
def computeGamma(Cf,Cf_):
    gamma={}
    for i in range(1,len(Cf)+1):
        gamma[i]=Cf.get(i)+Cf_.get(i)
    return gamma

def compute_dailyCost(model, Something):
    DailyCost={}
    for d in model.Days:
        DailyCost[(d)] = sum(Something[f,d] * model.c[f] for f in model.F)
    return DailyCost
def compute_monthlyCost(model, DailyCost):
    return sum(DailyCost[d] for d in model.Days)

def computeDailyExcessStockValue(model, shift):
    DailyExcess={}
    DailyValueinStock = compute_dailyCost(model, model.stock)
    for d in range(1, n_days+1):
        DailyExcess[(d)] = DailyValueinStock[d] - NextDaysXValue(model.Q, shift) # difference between stock value and next 2 days demand
    return DailyExcess

def NextDaysDemVal(t, nd): # valore della domanda dei 2 gg successivi
    DailyDemCost = {}
    for d in range(1, n_days + 1):
        DailyDemCost[d] = sum(Demand[f, d] * c[f] for f in range(1, n_drugs + 1))
    NextDem=0
    if (t==n_days):
        return NextDem
    else:
        for i in range(t+1, t+nd+1):
            if (i<=n_days):
                NextDem += DailyDemCost[i]
        return NextDem

# print var solution
def save_var_solution(varname, dim):
    if dim==1:
        Temp={}
        varobject = getattr(instance, varname)
        for index in range(1, len(varobject)+1):
            Temp[(index)] = varobject[index].value.__round__()
    if dim == 2:
        Temp = {}
        varobject = getattr(instance, varname)
        for index1 in range(1, n_drugs+1):
            for index2 in range(1, n_days+1):
                Temp[(index1, index2)] = varobject[index1, index2].value.__round__()
    return Temp

def same_group(Drugs_in_groups):
    group=[]
    for i in Drugs_in_groups.keys():
        if Drugs_in_groups[i]==1:
            #Drugs_in_groups[i]+=1
            group.append(i)
    return group

def compute_LBboxesDemandSat(dem, stock0, safe, n_doses): # min number of drug boxes
    # lower bound to number of drug boxes needed to satisfy demand in the planning horizon
    DemandSat = {}
    for f in range(1, n_drugs+1): #altrim usare model.l[f]=newInitStock
        DemandSat[(f)] = ceil((sum(dem[f,d] for d in range(1, n_days+1)) - stock0[f] + safe[f])/n_doses[f]) ## boxes conversion of(all doses needed - initstock) when d=1 InitStock is to be subtracted
        if DemandSat[f]<0:
            DemandSat[f] = 0
    return DemandSat


def computeDailyStock(D, Order, stock0):
    DailyStock = {}
    for d in range(1, n_days+1):
        for f in range(1, n_drugs+1):
            if d==1:
                DailyStock[(f,d)] = stock0[f] - D[f,d]
            else:
                DailyStock[(f,d)] = DailyStock[(f,d-1)] + (Order[f,d-1]*U[f]) - D[f,d]
    return DailyStock

# to guarantee 1st day demand satisfaction:
def check1dayDemSat(old, dem, posologGiorn1pz):
    newInitStock = {}
    for f in range(1, n_drugs+1):
        if dem[f,1]>old[f]: # 1st day demand
            newInitStock[(f)] = dem[f,1]
            print('1st day InitStock for drug '+str(f)+' changed since not enough to cover 1st day demand')
        else:
            newInitStock[(f)] = old[f]
    #print('opt newInitStock',newInitStock)
    return newInitStock





# nurses
def compute_numDiffDrugsOrdered(order, drug_orders): #number of different drugs ordered in a given day
    diff_drugs = {}
    for d in range(1, n_days+1):
        diff_drugs[(d)] = sum(vResults[f, d] for f in range(1, n_drugs + 1)) #[sum(1 for f in range(1, n_drugs+1)  if OrdersYResults[f,d]>0) for d in range(1, n_days+1)]
    return diff_drugs
def min_max_numOrderedDrugs(diff_drugs): # min and max number of drugs ordered in a given day
    Min = np.min([diff_drugs[d] for d in range(1, n_days+1) if diff_drugs[d]>0])
    Max = np.max([diff_drugs[d] for d in range(1, n_days+1) if diff_drugs[d]>0])
    return Min, Max


# general direction
def compute_boxesCost():
    boxesCost = {}
    for f in range(1, n_drugs+1):
        boxesCost[(f)] = U[f] * c[f]
    return boxesCost
def compute_ExcessOrderBoxes(Y, LB): #boxes ordered - boxes enough satisfy demand in the planning horizon
    excess = {}
    for f in range(1, n_drugs+1):
        excess[(f)] = sum(Y[f,d] for d in range(1, n_days+1)) - LB[f]
    return excess

# clinicians
def get_TEdrugs(TEdrugsSet): # returns a vector of all TEdrugs elements
    TEf = []
    for i in TEdrugsSet.keys():
        if np.isscalar(TEdrugsSet[i]):
            TEf.append(TEdrugsSet[i])
        else:
            for j in range(len(TEdrugsSet[i])):
                TEf.append(TEdrugsSet[i][j])
    return TEf
def check_TEdrugs(TEdrugsSet, stock):
    n_TE={}
    for d in range(1, n_days+1):
        n_TE[(d)] = int(stock[4, d] >= 2) + int(stock[5, d] >= 3) + int(stock[11, d] >= 4 and stock[12, d] >= 4) + int(stock[14, d] >= 4 or stock[15, d] >= 3)
    #     n_TE[(d)] = 0
    #     for i in TEdrugsSet.keys():
    #         if np.isscalar(TEdrugsSet[i]) and stock[TEdrugsSet[i],d] >= posologGiorn1pz[TEdrugsSet[i]]:
    #             n_TE[(d)] += 1
    #         elif np.isscalar(TEdrugsSet[i])==False:
    #             ok = 0
    #             for j in range(len(TEdrugsSet[i])):
    #                 if stock[TEdrugsSet[i][j],d] >= posologGiorn1pz[TEdrugsSet[i][j]]:
    #                     ok += 1
    #             if len(TEdrugsSet[i])==ok:
    #                 n_TE[(d)] += 1
    #n_TE = sum(int(int(stock[4, d] >= 2) + int(stock[5, d] >= 3) + int(stock[11, d] >= 4 and stock[12, d] >= 4) + int(stock[14, d] >= 4 or stock[15, d] >= 3) >= 3) for d in range(1, n_days + 1))
    return n_TE
def DrugInEmpTer(drug): # restituisce 1 se la drug f è usata nelle empter
    presente=False
    if drug in get_TEdrugs(TEdrugs):
        presente=True
    return int(presente)
