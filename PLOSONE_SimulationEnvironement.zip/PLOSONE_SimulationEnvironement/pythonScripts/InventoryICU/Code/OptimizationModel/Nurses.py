# nurses constraint


def con_NursesMin(model, d):
    return model.Vmin <= sum(model.v[f,d] for f in model.F) + (1 - model.nu[d]) * model.n_drugs
model.NursesMin = Constraint(model.Days, rule=con_NursesMin)
def con_NursesMax(model, d):
    return model.Vmax >= sum(model.v[f, d] for f in model.F)
model.NursesMax = Constraint(model.Days, rule=con_NursesMax)
def con_NursesRange(model, d):
    return model.Vmax - model.Vmin <= model.RangeV
model.NursesRange = Constraint(model.Days, rule=con_NursesRange)
