#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
from pandas import *
import pickle
import itertools
import math
import datetime
#from datetime import datetime, timedelta
import time
import os

from pyomo.environ import *
from pyomo.opt import *

import matplotlib.pyplot as plt
from pylab import plot, show, savefig, xlim, figure, \
                hold, ylim, legend, boxplot, setp, axes

codes_path=os.path.dirname(os.path.realpath("__file__" + "/../"))
data_path=str(os.path.dirname(os.path.realpath("__file__" + "/../../"))+"/Data/")

# load functions
exec(compile(open('./../functions.py', "rb").read(), './../functions.py', 'exec'))

#in rolling horizon framework this must be managed:
exec(compile(open(str(data_path + 'Data.py'), "rb").read(), str(data_path + 'Data.py'), 'exec'))


##############################################################################
##  BEGIN PYOMO MODEL
##############################################################################

model = AbstractModel()

##############################################################################
# sets
##############################################################################
model.F = Set(initialize=RangeSet(1, n_drugs)) # f farmaci tot
model.G = Set(initialize=RangeSet(1, n_SharedSpaces)) # g gruppi di farmaci
model.Days = Set(initialize=RangeSet(1, n_days)) # planning horizon

model.Fg = Set(initialize=same_group(Drugs_in_groups))#model.F) # farmaci del frigorifero #=SharedSpacesSets
#model.Fg_scaff = Set(initialize=(model.F - model.Fg)) # farmaci dell'armadietto
# ad ogni farmaco corrisponde un gruppo G di appartenenza
# se Drugs_in_groups==1 allora appartiene a g=2; se ==0 allora appartiene a g=1

##############################################################################
# parameters
##############################################################################
model.Q = Param(model.F, model.Days, initialize=Demand) # demand of drug f on day d of week w, number of doses
model.U = Param(model.F, initialize=U) # number of doses in each box of drug f
model.c = Param(model.F, initialize=c) # cost of each dose of drug f
model.B = Param(initialize=B) # B maximum allowed stock monetary value on day d of week w
newInitStock = InitStock #check1dayDemSat(InitStock, Demand, posologGiorn1pz)
model.l = Param(model.F, initialize=newInitStock, within=NonNegativeIntegers) #num dosi iniziale #doses of drug f in ward at time 0
model.posGiorn = Param(model.F, initialize=posologGiorn1pz)
#newInitStock > SafeStock
model.SafeStock = Param(model.F, initialize=SafeStock)

# boxes:
model.Cf = Param(model.F, initialize=Cf) #capacity of storage unit dedicated to drug f expressed in number of boxes
model.Cf_ = Param(model.F, initialize=Cf_) #c_segnato# maximum number of drug f boxes in shared storage unit
model.V = Param(model.F, initialize=V) #volume of a drug f box in number of units in shared storage unit
model.Vg = Param(model.G, initialize=Vg) #capacity of shared storage unit for group g, expressed in number of units
model.Gamma = Param(model.F, initialize=computeGamma(Cf,Cf_))  #upper bound on the maximum number of boxes of drug f in stock

model.OrderEventWeight = Param(initialize=OrderEventWeight)#peso componente ordine in funzione obiettivo
model.FirstWeekDay = Param(initialize=FirstWeekDay, within=NonNegativeIntegers)
model.n_days = Param(initialize=n_days, within=NonNegativeIntegers)
model.n_drugs = Param(initialize=n_drugs, within=NonNegativeIntegers)
model.n_SharedSpaces = Param(initialize=n_SharedSpaces, within=NonNegativeIntegers)
#model.Drugs_in_groups = Param(model.F, initialize=Drugs_in_groups)
model.ordinaryDT = Param(initialize=ordinaryDT, within=NonNegativeIntegers)

model.penaltyOnline = Param(initialize=EmergencyOrderPenalty)
model.budgetPenalty = Param(initialize=BudgetPenalty, within=NonNegativeIntegers)

##############################################################################
# Variables
# can have bounds and name
##############################################################################
# boxes
model.OrderY = Var(model.F, model.Days, within=NonNegativeIntegers) #order quantity of drug f on day d of week w expressed in number of boxes
model.v = Var(model.F, model.Days, within=Binary) # DrugOrderEvent: equal to 1 when an order of drug f occurs on day d of week w ; 0 otherwise
model.nu = Var(model.Days, within=Binary) # OrderEvent: equal to 1 when an order occurs on day d of week w; 0 otherwise
model.delta_f = Var(model.F, within=NonNegativeIntegers) #lot size S: order quantity of drug f expressed in number of boxes
model.x = Var(model.F, model.Days, within=NonNegativeIntegers) #number of boxes of drug f in the shared storage unit on day d of week w
model.s_reorderPoint = Var(model.F, within=NonNegativeIntegers) # reorder point
# doses
model.stock = Var(model.F, model.Days, within=NonNegativeIntegers) #stock level of drug f at the end of day d of week w expressed in number of doses
#new:
model.boxinStock = Var(model.F, model.Days, within=NonNegativeIntegers)
model.boxinStockRes = Var(model.F, model.Days, within=NonNegativeIntegers) # dedicated space
model.resCapFull = Var(model.F, model.Days, within=Binary) # whether dedicated space is full or not

model.ecstra = Var(within=NonNegativeReals)
model.DailyExcessStockValue = Var(model.Days)


LBboxes = compute_LBboxesDemandSat(Demand, newInitStock, SafeStock, U) #compute_LBboxesDemandSat(instance)

model.Online = Var(model.F, model.Days, within=Binary) # var binaria che determina se scatta l'ordine in emergenza
model.OnlineOrderY = Var(model.F, model.Days, within=NonNegativeIntegers) # quantitativo ordinato in emergenza
model.onlineL = Var(model.F, model.Days, within=Binary)  # var per linearizzazione vincolo ordine online giorni>1
############################
# Stakeholders declarations
# nurses
model.RangeV = Param(initialize = Target_Score_Nurses, within = NonNegativeIntegers)
#vars:
model.Vmin = Var(within = NonNegativeIntegers)
model.Vmax = Var(within = NonNegativeIntegers)

# general direction
model.Score_GeneralDirection = Param(initialize = Target_Score_GeneralDirection, within = NonNegativeReals)
model.LBboxes = Param(model.F, initialize = LBboxes, within = NonNegativeIntegers)
model.w_f = Param(model.F, initialize = boxesCost, within = NonNegativeReals) # weight
#vars:
model.extraBoxes = Var(model.F) # number of ordered boxes exceeding demand

# clinicians
model.Tj = Set(initialize = RangeSet(1, len(TEdrugs.keys()))) # equivalent therapies
model.Fe = Set(initialize = get_TEdrugs(TEdrugs)) # drugs in equivalent therapies
# drugs involved are in TEdrugs
model.Score_Clinicians = Param(initialize = Target_Score_Clinicians, within = NonNegativeIntegers)
model.thresholdScore_Clinicians = Param(initialize = thresholdScore_Clinicians) # ok if >= 3 (enough variety)
#vars:
model.alphaF = Var(model.Fe, model.Days, within = Binary) # equal to 1 if drug f is in stock on day d
model.betaT = Var(model.Tj, model.Days, within = Binary) # equal to 1 when therapy Tj is available on day d
model.Kte_avail = Var(model.Days, within = Binary) # lambda: equal to 1 when when at least K therapies in T are available in surplus on day d

##############################################################################
# Constraints
##############################################################################
# stock level at the end of day d = stock in d-1 - demand on d + order on d-1 except for day 0 (sunday)
# flow balance constraints on sunday (no arrivals): stock at the end of d = stock in d-1 - demand on d
def con_FlowBal(model, f, d):
    if d==1: # constraint (2)
        return model.stock[f,d] == model.l[f] - model.Q[f,d] + model.U[f] * model.OnlineOrderY[f,d] # starting level of the stocks
    elif (weekDay(d) > 0): # constraints (3) and (4)
        return model.stock[f,d] == model.stock[f,d-1] - model.Q[f,d] + model.U[f] * (model.OrderY[f,d-1] + model.OnlineOrderY[f,d])
    else:  # on Sunday no order is received
        return model.stock[f,d] == model.stock[f,d-1] - model.Q[f,d]
model.FlowBal = Constraint(model.F, model.Days, rule=con_FlowBal)

def con_UBstockLevel(model, f, d): # (5) upper bound on the maximum stock level that a given drug may assume on a given day of the planning horizon
    return model.stock[f,d] <= model.U[f] * (model.Cf[f] + model.x[f,d])
model.Capacity1 = Constraint(model.F, model.Days, rule=con_UBstockLevel)
def con_UBboxes(model, f, d): # (6) upper bound on the maximum number of boxes present in the common storage space
    return model.x[f,d] <= model.Cf_[f]
model.Capacity2 = Constraint(model.F, model.Days, rule=con_UBboxes)

def con_knapsack1(model, d): # (7)
    return sum(model.x[s,d] * model.V[s] for s in (model.F - model.Fg)) <= model.Vg[2]
model.Knapsack1 = Constraint(model.Days, rule=con_knapsack1)
def con_knapsack2(model, d):#refrig.
    return sum(model.x[s,d] * model.V[s] for s in model.Fg) <= model.Vg[1]
model.Knapsack2 = Constraint(model.Days, rule=con_knapsack2)

#precedenza allo spazio dedicato rispetto a quello comune:
def con_spaceChoice(model, f, d):
    return (model.boxinStock[f,d]-1) * model.U[f] + 1 <= model.stock[f,d]
model.spaceChoice = Constraint(model.F, model.Days, rule=con_spaceChoice)
def con_spaceChoice2(model, f, d):
    return model.stock[f,d] <= model.boxinStock[f,d] * model.U[f]
model.spaceChoice2 = Constraint(model.F, model.Days, rule=con_spaceChoice2)
def con_spaceChoice3(model, f, d):
    return model.boxinStock[f,d] == model.boxinStockRes[f,d] + model.x[f,d]
model.spaceChoice3 = Constraint(model.F, model.Days, rule=con_spaceChoice3)
def con_spaceChoice4(model, f, d):
    return model.boxinStockRes[f,d] <= model.Cf[f]
model.spaceChoice4 = Constraint(model.F, model.Days, rule=con_spaceChoice4)
def con_spaceChoice5(model, f, d):
    return model.resCapFull[f, d] <= model.boxinStockRes[f,d] / model.Cf[f]
model.spaceChoice5 = Constraint(model.F, model.Days, rule=con_spaceChoice5)
def con_spaceChoice6(model, f, d):
    return model.x[f,d] <= model.resCapFull[f,d] * model.Cf_[f]
model.spaceChoice6 = Constraint(model.F, model.Days, rule=con_spaceChoice6)


def con_budget(model, d):
    # DailyValueinStock = compute_dailyCost(model, model.stock)
    # return DailyValueinStock[d] <= model.B # (8)
    return sum(model.stock[f,d] * model.c[f] for f in model.F) - sum(model.SafeStock[f] * model.c[f] for f in model.F) - sum(model.U[f] * model.OnlineOrderY[f,d] * model.c[f] for f in model.F) <= model.B + model.ecstra
model.Budget = Constraint(model.Days, rule=con_budget)

# no orders on saturday and on the last day of the planning horizon (orders can't be received)
def con_noOE(model, d): # (9)
    if (weekDay(d)==6 or d==n_days):
        return model.nu[d] == 0
    else:
        return Constraint.Skip
model.noOE = Constraint(model.Days, rule=con_noOE)
def con_noDrugOE(model, f, d):
    if (weekDay(d)==6 or d==n_days):
        return model.v[f,d] == 0
    else:
        return Constraint.Skip
model.noDrugOE = Constraint(model.F, model.Days, rule=con_noDrugOE)
def con_noOE2(model, f, d):
    if (weekDay(d)==6 or d==n_days):
        return model.OrderY[f,d] == 0
    else:
        return Constraint.Skip
model.noOE2 = Constraint(model.F, model.Days, rule=con_noOE2)

def con_lotSize(model, f):# (10) upper bound on the lot size of drug f
    return model.delta_f[f] <= model.Gamma[f]
model.LotSize = Constraint(model.F, rule=con_lotSize)

def con_VarY(model, f, d): # (11)
    return model.OrderY[f,d] <= model.v[f,d] * model.Gamma[f]
model.VarY = Constraint(model.F, model.Days, rule=con_VarY)

def con_fixLotSize1(model, f, d): # (12)
    return model.OrderY[f,d] <= model.delta_f[f]
model.FixLotSize1 = Constraint(model.F, model.Days, rule=con_fixLotSize1)

def con_fixLotSize2(model, f, d): # (13)
    return model.OrderY[f,d] >= model.delta_f[f] - (1 - model.v[f,d]) * model.Gamma[f]
model.FixLotSize2 = Constraint(model.F, model.Days, rule=con_fixLotSize2)

def con_OEsetted(model, f, d): # (14) order event on a given day is equal to one if at least one drug is ordered on that day
    return model.v[f,d] <= model.nu[d]
model.OEsetted = Constraint(model.F, model.Days, rule=con_OEsetted)

def con_drug13(model, d): # il farmaco 13 è fantasma, non va mai ordinato!
    return model.v[13,d] == 0
model.drug13 = Constraint(model.Days, rule=con_drug13)

def con_everOrdered1(model, a, d): # se il quantitativo dello stock iniziale del farmaco è maggiore di quanto richiesto dalla domanda e dal safety stock allora non ordinarlo. Questo non deve valere per i farmaci del vincolo stakeholder medico
    if sum(model.Q[a,g] for g in model.Days) + model.SafeStock[a] <= model.l[a]:
        return model.v[a,d] == 0
    else:
        return Constraint.Skip
model.everOrdered1 = Constraint((model.F - model.Fe), model.Days, rule=con_everOrdered1)
def con_everOrdered2(model, a, d): # legato al vincolo precedente
    if sum(model.Q[a,g] for g in model.Days) + model.SafeStock[a] <= model.l[a]:
        return model.OrderY[a,d] == 0
    else:
        return Constraint.Skip
model.everOrdered2 = Constraint((model.F - model.Fe), model.Days, rule=con_everOrdered2)

def con_s_threshold(model, f, d): # punto di riordino
    return model.stock[f,d] >= model.s_reorderPoint[f]
model.s_threshold = Constraint(model.F, model.Days, rule=con_s_threshold)

def con_minStockLevel(model, f, d): # minimum stock daily required
    return model.stock[f,d] >= model.SafeStock[f]
model.MinStockLevel = Constraint(model.F, model.Days, rule=con_minStockLevel)

def con_excessStockValue(model, d):
    return model.DailyExcessStockValue[d] == sum(model.stock[f,d] * model.c[f] for f in model.F) - NextDaysDemVal(d, 2) # valore stock - domanda next 2days
model.excessStockValue = Constraint(model.Days, rule=con_excessStockValue)

def con_extraB(model, f): #DrugExtraOrderedBoxes -- ordered boxes exceeding demand
    return model.extraBoxes[f] == sum(model.OrderY[f,d] for d in model.Days) - model.LBboxes[f]
model.extraB = Constraint(model.F, rule=con_extraB)

# emergency order: se scatta vengono ordinate il minimo numero di scatole necessarie a coprire domanda e safety stock [SOLO GIORNO 1]
def con_onlineOrder(model,f,d):
    if d == 1:
        return model.Online[f,d] <= 1
    else:
        return model.Online[f,d] == 0
model.onlineOrder = Constraint(model.F, model.Days, rule=con_onlineOrder)
def con_onlineOEsetted(model,f,d):
    if d == 1:
        return model.OnlineOrderY[f,d] <= ceil((model.Q[f,d]+model.SafeStock[f]-model.l[f])/model.U[f]) * model.Online[f,d]
    else:
        return model.OnlineOrderY[f,d] == 0
model.onlineOEsetted = Constraint(model.F, model.Days, rule=con_onlineOEsetted)


###############################
## STAKEHOLDERS CONSTRAINTS ##
# nurses
exec(compile(open(str(codes_path + '/OptimizationModel/Nurses.py'), "rb").read(), str(codes_path + '/OptimizationModel/Nurses.py'), 'exec'))
# general direction
#exec(compile(open(str(codes_path + '/OptimizationModel/GeneralDirection.py'), "rb").read(), str(codes_path + '/OptimizationModel/GeneralDirection.py'), 'exec'))
# clinicians
#exec(compile(open(str(codes_path + '/OptimizationModel/Clinicians.py'), "rb").read(), str(codes_path + '/OptimizationModel/Clinicians.py'), 'exec'))


##############################################################################
# Obj function
##############################################################################
def OBJ_rule(model):
    return (model.OrderEventWeight * sum(model.nu[d] for d in model.Days)) + ((sum(sum(model.stock[f,d] * model.c[f] for f in model.F) for d in model.Days))/model.B) + model.penaltyOnline * (sum(model.Online[f,d] for d in model.Days for f in model.F)) + model.ecstra
model.OBJ = Objective(rule=OBJ_rule, sense=minimize)

##############################################################################
##  END MODEL
##############################################################################

instance = model.create_instance()

#import cplex
#/Users/roberta/Applications/IBM/ILOG/CPLEX_Studio1271/cplex/python/3.5/x86-64_osx/setup.py
#/Users/roberta/Applications/IBM/ILOG/CPLEX_Studio1271/cplex/bin/x86-64_osx/cplex


# create a Python object to interface to the cplex solver:
#opt=SolverFactory("cplex", solver_io="lp", executable="/Users/roberta/anaconda/envs/py3k/bin/cplex")
#opt.mip.tolerances.mipgap=0.000001

executablePath= os.path.dirname(os.path.realpath(__file__)) + "/cplex"
opt=SolverFactory("cplex", solver_io="lp", executable=executablePath)
opt.options.mipgap = 0.0000001
opt.options.timelimit = 1800

#instance.write('/Users/roberta/Dropbox/InventoryICU/Code/OptimizationModel/pyomo.lp')#, io_options={'symbolic_solver_labels': True})
results = opt.solve(instance, tee=True)#, symbolic_solver_labels=True) #timelimit=1000000 #results = opt.solve(instance)
#timelimit= #seconds

instance.solutions.store_to(results) # to store the results to the results object
#print(results)
#results.write() #This output is in the YAML
#results.write_json()

# if results.solver.termination_condition != TerminationCondition.optimal:
#     raise RuntimeError('Solver did not report optimality:\n%s' % (results.solver))



#########################
### save var solutions
nuResults = None
nuResults = save_var_solution('nu', 1)

tot_order_events = None
tot_order_events = sum(nuResults.values()).__round__() #n order events

OrdersYResults = None
OrdersYResults = save_var_solution('OrderY', 2)

vResults = None
vResults = save_var_solution('v', 2)

delta_fResults = None
delta_fResults = save_var_solution('delta_f', 1)
lotSizes = {}
for f in range(1, n_drugs+1):
    lotSizes[(f)] = 0
    for d in range(1, n_days + 1):
        if OrdersYResults[f,d] > lotSizes[f]:
            lotSizes[(f)] = OrdersYResults[f,d]

drugs_NtimesOrdered = {}
for f in range(1, n_drugs+1):
    drugs_NtimesOrdered[(f)] = sum(vResults[f,d] for d in range(1, n_days + 1))

xResults = None
xResults = save_var_solution('x', 2)

stockResults = None
stockResults = save_var_solution('stock', 2)

extraBoxesVar = save_var_solution('extraBoxes', 1)
for f in range(1, n_drugs+1):
    if extraBoxesVar[f] < 0:
        extraBoxesVar[f] = 0

s_reorderPoint = None
s_reorderPoint = save_var_solution('s_reorderPoint', 1)

boxinStock = None
boxinStock = save_var_solution('boxinStock', 2)
boxinStockRes = None
boxinStockRes = save_var_solution('boxinStockRes', 2)
resCapFull = None
resCapFull = save_var_solution('resCapFull', 2)
ecstra = getattr(instance, 'ecstra').value
DailyExcessStockValue = None
DailyExcessStockValue = save_var_solution('DailyExcessStockValue', 1)

#varOnline = save_var_solution('Online', 1)
varOnlineOrderY = save_var_solution('OnlineOrderY', 2)

var_results = None
var_results = {'tot_order_events':tot_order_events,
               'daysOrders':[i for i in range(1,len(nuResults)+1) if nuResults.__getitem__(i)>0],
               'lotSizes':lotSizes,
               'OrdersYResults':OrdersYResults,
               'xResults':xResults,
               'stockResults':stockResults,
               'DailyExcessStockValue': DailyExcessStockValue,
               'nuResults':nuResults,
               'vResults':vResults,
               'delta_fResults':delta_fResults,
               's_reorderPoint':s_reorderPoint,
               'boxinStock':boxinStock,
               'boxinStockRes':boxinStockRes,
               'resCapFull':resCapFull,
               'ecstra':ecstra,
               #'varOnline' : varOnline,
               'varOnlineOrderY': varOnlineOrderY
              }


###############################
## STAKEHOLDERS PERSPECTIVES ##
# nurses constraint
#ndiff_drugs = compute_numDiffDrugsOrdered(nuResults, vResults)
#Score_Nurses = min_max_numOrderedDrugs(ndiff_drugs)[1] - min_max_numOrderedDrugs(ndiff_drugs)[0]# Range = Max - Min
# general direction constraint
extraBoxes = compute_ExcessOrderBoxes(OrdersYResults, LBboxes) #n_extraboxes
Score_GeneralDirection = sum(extraBoxes[f] * boxesCost[f] for f in range(1, n_drugs+1)) # tot extra cost (valore ordini in eccesso)
# clinicians constraint
Score_Clinicians = sum(check_TEdrugs(TEdrugs, stockResults)[d] >= thresholdScore_Clinicians for d in range(1, n_days+1))

######################
### save solution
# print orders matrix
f_orders = open(str(data_path+"/OrdersMatrix.txt"),'w')
dict_to_df(OrdersYResults).to_csv(f_orders, sep='\t', index=False, header=False)
f_orders.write('\n')
f_orders.close()

f_online_orders = open(str(data_path+"/EmergencyOrders/EmergencyOrdersMatrix.txt"),'w')
dict_to_df(varOnlineOrderY).to_csv(f_online_orders, sep='\t', index=False, header=False)
# sforamento percentuale del budget rispetto a quello "aumentato" dal costo del livello di sicurezza:
# (valore stock + sforamento budget)/(budget + valore safety stock)
f_online_orders.write('\n'+str(ecstra)+'\t(sforamento budget)'+'\n'+str(round(((sum(stockResults[f,d]*c[f] for f in range(1,n_drugs+1) for d in range(1, n_days+1)) + ecstra)/(B + sum(SafeStock[f] * c[f] for f in range(1, n_drugs+1)))),2))+'\t(percentuale)')
f_online_orders.write('\n')
f_online_orders.write('\nOrdersMatrix:\n')
dict_to_df(OrdersYResults).to_csv(f_online_orders, sep='\t', index=False, header=False)
f_online_orders.write('\n')
f_online_orders.close()


#
f = open(str(codes_path+'/OptimizationModel/Time.txt'),'a')
# f.write(str(results))
# f.write(str("---------------------------------------------\n"))
# f.write(str("\nTot order events: "+str(int(tot_order_events))+"\n"))
# f.write(str("\ndays: "+str([i for i in range(1,len(nuResults)+1) if nuResults.__getitem__(i)>0])))
# f.write(str('\nlot sizes: '+str(lotSizes)))
# f.write(str("\nOrdersY\n"))
# dict_to_df(OrdersYResults).to_csv(f, sep='\t', index=False)
# f.write(str("\nStock\n"))
# dict_to_df(stockResults).to_csv(f, sep='\t', index=False)
# f.write(str("---------------------------------------------\n"))
# f.write(str('\nTotDemand doses: '+str(sum(Demand[f,d] for f in range(1,n_drugs+1) for d in range(1, n_days+1)))))
# f.write(str('\nTotDemandValue: '+str(sum(Demand[f,d]*c[f] for f in range(1,n_drugs+1) for d in range(1, n_days+1)))))
# f.write(str('\nTotStockValue: '+str(sum(stockResults[f,d]*c[f] for f in range(1,n_drugs+1) for d in range(1, n_days+1)))))
#
# # nurses
# f.write(str('\nScore_Nurses: '+str(Score_Nurses)))
# f.write(str('\nndiff_drugs: '+str(ndiff_drugs)))
# f.write(str('\nScore_GeneralDirection: '+str(Score_GeneralDirection)))
# f.write(str('\nn_extraboxes: '+str(sum(extraBoxes[f] for f in range(1, n_drugs+1)))))
# f.write(str('\nLBboxes: '+str(LBboxes)))
# f.write(str('\nboxCost: '+str(boxesCost)))
# f.write(str('\nextraboxes: '+str([extraBoxes[f] for f in range(1, n_drugs+1)])))
# f.write(str('\n Extracost: '+str([extraBoxes[f] * boxesCost[f] for f in range(1, n_drugs+1)])))
# f.write(str('\nClinicians score:', Score_Clinicians))
#
#
# f.write('\n\n##############\nSolution Information\n##############')
f.write(str('Time: '+str(results.solver.Time)+' TerminationCondition: '+str(results.solver.termination_condition)+' Gap: '+str(results['Solution'].Gap)+'\n'))
# f.write(str('\nObjectiveF value: '+str(results['Solution'].Objective['OBJ']['Value'])))
# f.write(str('\nGap: '+str(results['Solution'].Gap)))
# # Solver Information
# f.write(str('\n##############\nSolver Information\n##############'))
# f.write(str('\nsolver Statistics: '+str(results.solver.Statistics)))
# f.write(str('\nUser time: '+str(results.solver.user_time)))
# f.write(str('\nTime: '+str(results.solver.Time)))
#
f.close()
#
#
#
print('\n##############\nSolution Information\n##############')
print('TerminationCondition:',results.solver.termination_condition)
print('ObjectiveF value:',results['Solution'].Objective['OBJ']['Value'])#results['Solution'].Objective
print('Gap:',results['Solution'].Gap)
# # Solver Information
# print('\n##############\nSolver Information\n##############\n')
# print('solver Statistics:',results.solver.Statistics)
# print('User time:',results.solver.user_time)
# print('Time:',results.solver.Time) #Solution time = 2.88 sec.
#
# print('tot demand value:',
#     sum([sum(Demand[f, d] * c[f] for d in range(1, n_days + 1)) for f in range(1, n_drugs + 1)]),
#     '\ntot stock value:',
#     sum([sum(stockResults[f, d] * c[f] for d in range(1, n_days + 1)) for f in range(1, n_drugs + 1)]))
#
# print('tot doses', sum(Demand.values()))
# print('# doses/drug',
#       [sum(Demand[f, d] for d in range(1, n_days + 1)) for f in range(1, n_drugs + 1)])
#
# print('ObjectiveF value:', results['Solution'].Objective['OBJ']['Value'])  # results['Solution'].Objective
#
print('n order events:', tot_order_events)
print('Days_order', [d for d in range(1, n_days+1) if sum(OrdersYResults[f,d]>0 for f in range(1, n_drugs+1))]) #[d for d in range(1, n_days+1) if nuResults[d]>0]
# print('lotSizes', [var_results['lotSizes'][i+1] for i in range(len(var_results['lotSizes']))])
# print('drugs_NtimesOrdered', np.array(dict_to_df(OrdersYResults).apply(np.count_nonzero, axis=1)))
# print('Nurses score:', Score_Nurses,
#       '\nn drugs in each order:', [sum(1 for f in range(1, n_drugs + 1) if OrdersYResults[f, d] > 0) for d in range(1, n_days + 1)],
#       '\nmean nurses score:', sum(ndiff_drugs[i] for i in range(1, len(ndiff_drugs) + 1) if ndiff_drugs[i] > 0) / tot_order_events)
#
# print('General direction score:', Score_GeneralDirection,
#       '\nn_extraboxes:', sum(extraBoxes.values()),
#       '\nn_extraboxes var:',sum(extraBoxesVar.values()),
#       'n_drugsWithExtraBoxes:', sum(1 for i in range(1, n_drugs + 1) if extraBoxes[i] > 0))
#
# print('Clinicians score:', Score_Clinicians)
# #print('sforamento budget: ', ecstra)
# #print('orders weekdays',[weekDay(d) for d in range(1, n_days+1) if sum(OrdersYResults[f,d] for f in range(1, n_drugs+1))])
#
#
#
#
# # # verifica vincoli capacità:
# # for d in range(1, n_days+1):
# #     if sum(stockResults[f,d] for f in range(1, n_drugs +1) if Drugs_in_groups[f] == 0) > Vol[0]:
# #         print('on day',d,'capacity bound not respected:',Vol[0])
# #     if sum(stockResults[f,d] for f in range(1, n_drugs+1) if Drugs_in_groups[f] == 1) > Vol[1]:
# #     #if sum(xResults[f, d] * U[f] for f in range(1, n_drugs + 1) if Drugs_in_groups[f] == 1) > Vol[1]:
# #         print('on day',d,'capacity bound not respected:',Vol[1])
# # print('\n\nCapacity bound analysis finished')
# # # verifica domanda sia soddisfatta:
# # print('Demand satisfaction check:\n',[str('failed on day '+str(d)+' for drug '+str(f)) for f in range(1, n_drugs +1) for d in range(1, n_days+1) if stockResults[f,d] < 0])
# # # verifica non vengano effettuati ordini di sabato:
# # print([str('Error! Order on saturday '+str(d)) for d in range(1, n_days+1) for f in range(1, n_drugs +1) if (weekDay(d)==6 and OrdersYResults[f,d]>0)])
# #



