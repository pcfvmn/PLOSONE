#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#############
import numpy as np
from pandas import *
import pickle
import itertools
import math
import datetime
#from datetime import datetime, timedelta
import time
import sys
import os
from ast import literal_eval
import collections
from itertools import groupby


p_classes = 3

n_days=int(sys.argv[1]) # prende in ingresso il planning horizon
n_wards=int(sys.argv[1]) # e il numero di reparti

this_path=str(os.path.dirname(os.path.realpath("__file__" )))
data_path=str(os.path.dirname(os.path.realpath("__file__" + "/../"))+"/Data/")

exec(compile(open(str(this_path + '/functions.py'), 'rb').read(), str(this_path + '/functions.py'), 'exec'))
exec(compile(open(str(this_path + '/distribData.py'), 'rb').read(), str(this_path + '/distribData.py'), 'exec'))

# daily doses to administrate for each drug
capacity = read_table(str(data_path+"/Capacity18drugs.txt"), sep='\t')
drugDoses = read_table(str(data_path+"/Dosi1posologia.txt"), sep='\t')

# paths
paths = read_table(str(data_path+'/Distrib/'+str(p_classes)+'pTypes_TchangesPaths.txt'), sep='\t')
paths.daysDrugs = paths.daysDrugs.apply(literal_eval)

# prende in ingresso lo stato attuale del reparto
currentPatients = read_table(str(data_path+"WardsStatus/currentPatients.txt"), sep='\t')

n_beds = 8 # tot number of beds
results_DT = 3 # lab results delay time
treatment_length = 5 #days
n_drugs = 18

# inizializzazioni
pathChoice = -1 # None
Demand={w:{(i,j):0 for i in range(1, n_drugs+1) for j in range(1, n_days+1)} for w in range(1,n_wards+1)}
# dict(reparto, giorno) per tenere traccia di quanti pazienti sono presenti ogni giorno
wardsOccupation = {(w,j):0 for w in range(1, n_wards+1) for j in range(1, n_days+1)} # inizializzo a 0 la matrice 18 farmaci x max los=82
# per statistiche: tengo traccia di tipologia, ggAmmissione, los e idPath di ciascun paziente:
admittedPatients = {(w,j):[] for w in range(1, n_wards+1) for j in range(1, n_days+1)}
#refusedPatients = {(i,j):[] for i in range(1, n_wards+1) for j in range(1, n_days+1)}



def patientType():  # discrete distribution driven choice
    return int(np.random.uniform(1, p_classes+1))
    #return int(np.random.choice([i for i in p_pzType.TipologiaPaziente], 1, p=[j for j in p_pzType.Prob]))
def getNarrivals(df):
    dice = (np.random.choice(np.append([i for i in df.arrivi.values], 'False'), 1, p=np.append([j for j in df.prob.values], (1-sum([j for j in df.prob.values])))))[0]
    while dice == 'False':
        dice = (np.random.choice(np.append([i for i in df.arrivi.values], 'False'), 1, p=np.append([j for j in df.prob.values], (1-sum([j for j in df.prob.values])))))[0]
    return int(dice)
# il paziente può avere o meno il sospetto di infezione
def labIssueEvent(iPz):  # is there lab issue? (iRic = 0 = current issue occurrences)
    p0 = float(p_req[p_req.TipologiaPaziente == iPz].ProbRichiestaSI)
    dice = int(np.random.choice([0, 1], 1, p=[(1 - p0), (p0)]))
    return dice
# 2 alternative:
# - scelta tra tutti i paths possibili
# - scelta prima della nuvoletta e poi di un cammino al suo interno
def getPathIndex(df): # restituisce l'indice del cammino, date le prob dei cammini
    choice = np.random.choice(np.append([i for i in df.index], 'False'), 1, p=np.append([i for i in df.probPath], (1 - sum(i for i in df.probPath))))
    while choice == 'False':
        choice = np.random.choice(np.append([i for i in df.index], 'False'), 1, p=np.append([i for i in df.probPath], (1-sum(i for i in df.probPath))))
    return int(choice[0])
def pathsGroupChoice(df):
    choice = np.random.choice(np.append([i for i in df.group.unique()], 'False'), 1, p=np.append([i for i in df.groupProb.unique()], (1 - sum(i for i in df.groupProb.unique()))))
    while choice == 'False':
        choice = np.random.choice(np.append([i for i in df.group.unique()], 'False'), 1, p=np.append([i for i in df.groupProb.unique()], (1 - sum(i for i in df.groupProb.unique()))))
    return int(choice[0])
# degenza per paziente senza sospetto di infezione
def is_outlier(): #(=5%prob) indipendente dalla tipologia del paziente
    return int(np.random.choice([0, 1], 1, p=[0.95, 0.05]))
def get_noOutlierLOS(iPz):
    # to fix round-off errors:
    dice=(np.random.choice(np.append([i for i in p_LoS_noreq.columns[1:]], 'False'), 1, p=np.append([j for j in p_LoS_noreq[p_LoS_noreq.TipologiaPaziente == iPz].iloc[0][1:].values], (1-sum(j for j in p_LoS_noreq[p_LoS_noreq.TipologiaPaziente == iPz].iloc[0][1:].values)))))[0]
    while dice == 'False':
        dice = (np.random.choice(np.append([i for i in p_LoS_noreq.columns[1:]], 'False'), 1, p=np.append( [j for j in p_LoS_noreq[p_LoS_noreq.TipologiaPaziente == iPz].iloc[0][1:].values], (1 - sum(j for j in p_LoS_noreq[p_LoS_noreq.TipologiaPaziente == iPz].iloc[0][1:].values)))))[0]
    return int(dice)
def updateDemand(administratedDrugs, drug, gg):
    # prende in ingresso la domanda da aggiornare, il farmaco e il giorno nel quale aggiungerlo
    # restituisce la domanda aggiornata
    if drug!=0:
        if np.isscalar(drug):  # every drug is an int but 4th empirical treatment, which is is a vector of 2 drugs
            administratedDrugs[drug, gg] += int(capacity[capacity.Farmaco == drug].dosi1posologia)
        else:
            administratedDrugs[drug[0], gg] += int( capacity[capacity.Farmaco == drug[0]].dosi1posologia)  # 4th empirical treatment administration
            administratedDrugs[drug[1], gg] += int( capacity[capacity.Farmaco == drug[1]].dosi1posologia)  # 4th empirical treatment administration
    return administratedDrugs


# funzione che aggiunge un paziente per ogni giorno di sua degenza prevista
def newPatientInfo(p,t,a,l):
    return {'idPath':p, 'type':t, 'admissionDay':a, 'los':l}




def getDmatrix(dict_data, x_max, y_max):
    converted = DataFrame()
    for j in range(1, y_max + 1):
        converted[(j)] = [dict_data[i, j] for i in range(1, x_max + 1)]
    return DataFrame(converted)


for w in range(1,n_wards+1):
    #print('ward',w)
    currentDay = 1
    #1) leggo i pazienti presenti, le terapie associate, aggiorno la domanda e l'occupazione del reparto
    # pazienti già presenti in reparto e che possono prendere cammino alternativo al previsto
    # dal idPath risalgo alla nuvoletta e prendo con distrib empirica una terapia da quella nuvoletta (NB: che potenzialmente può essere lo stesso)
    for p in currentPatients[currentPatients.ward==w].index:
        if currentPatients.loc[p].idPath != -1: #'None': # se paziente ha sospetto infezione
            idG = paths.loc[int(currentPatients.loc[p].idPath)].group
            pathsPz = paths[paths.p_type == currentPatients.loc[p].p_type]
            pathChoice = getPathIndex(pathsPz[pathsPz.group==idG])
            #currentPatients.loc[p].indexD #giorno dal quale parte la somministrazione
            #print('pz con farmaci',pathsPz.loc[pathChoice].daysDrugs)
            if currentPatients.loc[p].indexD < len(pathsPz.loc[pathChoice].daysDrugs): # il modello viene lanciato la sera quindi le somministrazioni del giorno sono già state fatte
                for g in range(len(pathsPz.loc[pathChoice].daysDrugs) - currentPatients.loc[p].indexD):
                    if g <= n_days:
                        Demand[w] = updateDemand(Demand[w], pathsPz.loc[pathChoice].daysDrugs[g+currentPatients.loc[p].indexD], currentDay+g)
                        wardsOccupation[w, currentDay+g] += 1
            admittedPatients[w, currentDay].append(newPatientInfo(pathChoice, currentPatients.loc[p].p_type, currentDay-currentPatients.loc[p].indexD, len(pathsPz.loc[pathChoice].daysDrugs)))
        else:
            pathChoice = -1 #None
            outlier = is_outlier()
            if outlier == 1:
                min = int(p_LoS_outlier_noreq[p_LoS_outlier_noreq.TipologiaPaziente == currentPatients.loc[p].p_type].Min)
                max = int(p_LoS_outlier_noreq[p_LoS_outlier_noreq.TipologiaPaziente == currentPatients.loc[p].p_type].Max)
                los = int(np.random.uniform(min, max))
            else:
                los = get_noOutlierLOS(currentPatients.loc[p].p_type)
            if currentPatients.loc[p].indexD < los: # il modello viene lanciato la sera quindi la degenza continua dal giorno dopo
                for g in range(los - currentPatients.loc[p].indexD):
                    wardsOccupation[w, currentDay + g] += 1
            admittedPatients[w, currentDay].append(newPatientInfo(pathChoice, currentPatients.loc[p].p_type, currentDay-currentPatients.loc[p].indexD, los))
            #print('los pz senza farmaci',los)
        #print('wardOccupation',[wardsOccupation[w,d] for d in range(1,n_days+1)])
    #print('admittedPatients',admittedPatients)
    # dal giorno successivo possono arrivare nuovi pazienti
    #2) controllo nuovi arrivi, per ogni tipologia e aggiorno la rispettiva domanda
    #print('day',currentDay,'\nletti occupati',[wardsOccupation[w,d] for d in range(1,n_days+1)],'\ndemand',getDmatrix(Demand[w],n_drugs,n_days))
    currentDay += 1
    while currentDay <= n_days:
        newPatients={c:getNarrivals(p_arriv[p_arriv.TipologiaPaziente==c]) for c in range(1, p_classes+1)}
        #
        # arrivi
        #
        #print('day', currentDay,'newPatients',newPatients,'wardsOccupation',[wardsOccupation[w,d] for d in range(1,n_days+1)])
        while wardsOccupation[w, currentDay] < n_beds and sum(newPatients[p] for p in range(1, p_classes+1))>0: #se ci sono ancora letti liberi o oggi non arrivano più pazienti
            #if sum(newPatients[p] for p in range(1, p_classes+1))>0:
            indexPz = patientType()
            while newPatients[indexPz]>0 and wardsOccupation[w, currentDay] < n_beds:
                #scelta la tipologia la decremento dagli arrivi
                newPatients[indexPz]-=1
                #
                # gestione paziente
                #
                # analisi sospetto infezione
                flag = labIssueEvent(indexPz)
                # paziente senza sospetto di infezione
                if flag == 0:
                    outlier = is_outlier()
                    if outlier == 1:
                        min = int(p_LoS_outlier_noreq[p_LoS_outlier_noreq.TipologiaPaziente == indexPz].Min)
                        max = int(p_LoS_outlier_noreq[p_LoS_outlier_noreq.TipologiaPaziente == indexPz].Max)
                        los = int(np.random.uniform(min, max))
                    else:
                        los = get_noOutlierLOS(indexPz)
                # paziente con sospetto di infezione
                if flag == 1:
                    pathsPz = paths[paths.p_type == indexPz]
                    # metodo1
                    # scelta tra tutti i paths possibili
                    # pathChoice = getPathIndex(pathsPz)
                    # metodo2
                    # scelta prima della nuvoletta e poi di un cammino al suo interno:
                    idG = pathsGroupChoice(pathsPz)
                    pathChoice = getPathIndex(pathsPz[pathsPz.group == idG])
                    # pathsPz.loc[pathChoice].daysDrugs = farmaci corrispondenti al cammino scelto --> la lunghezza di questo vettore mi dà anche la LOS
                    los = len(pathsPz.loc[pathChoice].daysDrugs)
                    #print('pz con farmaci',pathsPz.loc[pathChoice].daysDrugs)
                    # aggiorno la domanda
                    for g in range(los):
                        if currentDay + g <= n_days:
                            Demand[w] = updateDemand(Demand[w], pathsPz.loc[pathChoice].daysDrugs[g], currentDay + g)
                admittedPatients[w,currentDay].append(newPatientInfo(pathChoice, indexPz, currentDay, los))
                #print('day',currentDay,'\nadmittedPatients',admittedPatients[w,currentDay],'\ndemand',getDmatrix(Demand[w],n_drugs,n_days))

                # aggiorno occupazione reparto
                for g in range(los):
                    if currentDay+g <= n_days:
                        wardsOccupation[w, currentDay + g] += 1
                #print('wardsOccupation:',wardsOccupation[w, currentDay])
                pathChoice = -1
        currentDay+=1







f_out = open(str(data_path+'Demand/1administrationMatrix.txt'),'w')
getDmatrix(Demand[1],n_drugs,n_days).to_csv(f_out, sep='\t', index=False, header=False)
f_out.write('\n')
f_out.close()
f_out = open(str(data_path+'Demand/2administrationMatrix.txt'),'w')
getDmatrix(Demand[2],n_drugs,n_days).to_csv(f_out, sep='\t', index=False, header=False)
f_out.write('\n')
f_out.close()

# demand analysis
print(sum(Demand[1][i,j] for i in range(1, n_drugs+1) for j in range(1, n_days+1)))
print(sum(Demand[2][i,j] for i in range(1, n_drugs+1) for j in range(1, n_days+1)))

drugsDoses=DataFrame([getDmatrix(Demand[w],n_drugs,n_days).sum(axis=1) for w in range(1,n_wards+1)]).T


# path changes prob analysis
currentPatients['changedPath']=[str(admittedPatients[w,1][j]['idPath']) for w in range(1,n_wards+1) for j in range(len(admittedPatients[w,1]))]

f_out = open(str(data_path+'WardsStatus/changedPaths.txt'),'w')
currentPatients.to_csv(f_out, sep='\t', index=False, header=True)
f_out.write('\n')
#f_out.write('prob same path: '+str([np.round((currentPatients[currentPatients.ward==w][currentPatients.idPath!='None'].changedPath==currentPatients[currentPatients.ward==w][currentPatients.idPath!='None'].idPath).astype(int).mean(),2) for w in range(1,n_wards+1)]))
# occupazione reparto
f_out.write('\n\nstat\nmean wardsOccupation: '+str([np.round(np.mean([wardsOccupation[w,d] for d in range(1,n_days+1)]),2) for w in range(1,n_wards+1)]))
# tipologia paziente
#f_out.write('\npatient type: '+str({p:[collections.Counter([(admittedPatients[w,1][j]['type']) for j in range(len(admittedPatients[w,1]))])[p]/len(admittedPatients[w,1]) for w in range(1,n_wards+1)] for p in range(1,p_classes+1)}))
#demand
f_out.write('\ntot demand doses: '+str([getDmatrix(Demand[w],n_drugs,n_days).sum().sum() for w in range(1,n_wards+1)])+'\ndrugs demand doses\nward1\tward2\n')
drugsDoses.to_csv(f_out, sep='\t', index=False, header=False)
f_out.write('\n\n')
f_out.close()






# pathsPz=paths[paths.p_type==indexPz]
#
# #scelta tra tutti i paths possibili
# all_drugs = getTreatmentPlan(pathsPz)
# # scelta prima del gruppo e poi di un cammino al suo interno:
# idG = pathsGroupChoice(pathsPz)
# all_drugs = getTreatmentPlan(pathsPz[pathsPz.group==idG])
#
#

