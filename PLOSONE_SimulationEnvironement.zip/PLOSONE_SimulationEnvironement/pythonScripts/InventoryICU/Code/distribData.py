#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pandas import *

# load data

# prob patient admission
p_admiss=read_table(str(data_path+'/Distrib/LettiLiberi.txt'), sep='\t').round(2)

# prob patient type arrivals
p_arriv = read_table(str(data_path+'/Distrib/Arrivi.txt'), sep='\t').round(2)

# prob patient type
p_pzType=read_table(str(data_path+'/Distrib/TipologiaPaziente.txt'), sep='\t').round(2)

# prob death patient with lab issues and after how many days it happens
#p_death_req=read_table(str(data_path+'/Distrib/Decesso.txt'), sep='\t').round(2)
#p_DTdeath_req=read_table(str(data_path+'/Distrib/DTdecesso.txt'), sep='\t').round(5)

# prob length of stay (regular patient and with no lab issues)
p_LoS_noreq=read_table(str(data_path+'/Distrib/DegenzaNoRichieste.txt'), sep='\t').round(2)
# prob length of stay (outlier patient and with no lab issues)
p_LoS_outlier_noreq=read_table(str(data_path+'/Distrib/OutlierDegenzaNoRichieste.txt'), sep='\t').round(2)

# prob any lab issue events and how many
p_req=read_table(str(data_path+'/Distrib/Richieste.txt'), sep='\t').round(2)
# delay time lab issue events
#p_DTreq=read_table(str(data_path+'/Distrib/DTrichieste.txt'), sep='\t').round(2)

# prob positive result
#p_positive=read_table(str(data_path+'/Distrib/RisultatiPositivi.txt'), sep='\t').round(2)

# prob drug susceptibility
#p_targetedT=read_table(str(data_path+'/Distrib/TerapiaMirata.txt'), sep='\t').round(3)
# drugs for empirical treatment
#empiricalTdrugs=[2,4,5,11,12,13,14,15,17,18] # uniform distrib.
TEdrugs = {1: [14, 15], # in OR
           2: 4,
           3: 5,
           4: [11, 12] # in AND
           }

